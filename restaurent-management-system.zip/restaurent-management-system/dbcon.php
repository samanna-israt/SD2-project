<?php
  $sql=mysqli_connect('localhost','root','','restaurentms');

  if($sql==true)
  {
     
  }
  

?>