<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home</title>
    <link rel="stylesheet" href="stylee.css">
</head>
<body>
    <nav class="navbar">
    <div class="left-nav">
            <h3>Admin Pannel</h3>
        </div>
        <div class="right-nav">
            <ul>
                <li class="item"><a href="aroom.php">Rooms</a></li>
                <li class="item"><a href="adminfood.php">Food</a></li>
                <li class="item"><a href="../index.php">user</a></li>
                
                
            </ul>
        </div>
    </nav>
    <section id="home">
    <div style="background:rgba(255,255,255,0.5); width:80%; height:100px">
    
    <h1 style="color:blue; text-align:center; font-size:30px; padding-top:20px">Welcome Admin</h1>

</div>
    </section>
</body>
</html>