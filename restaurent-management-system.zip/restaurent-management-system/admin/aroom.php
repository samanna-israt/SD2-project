<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Room</title>
    <link rel="stylesheet" href="stylee.css">
</head>
<style>
    .h1{
        text-align:center;
        margin-top: 20px;
    }
</style>
<body>
    <div class="wrapper-container">
    <div class="wrapper">
        <ul>
            <li><a href="aroom.php">Room Home</a></li>
            <li><a href="#">Room Update</a>
                    <ul>
                        <li><a href="adelux.php">Delux ac</a></li>
                        <li><a href="aac.php"> ac</a></li>
                        <li><a href="anonac.php">Non ac</a></li>
                    </ul>
            </li>
            <li><a href="booking.php">Booking</a></li>
            <li><a href="roomdetails.php">Room Details</a></li>
            <li><a href="admindash.php">Admin Dash</a></li>
            
        </ul>
    </div>
    </div>
    <div class="h1">
        <h1>Welcome Admin, To Admin Room Home Section</h1>
        <img src="../img/hotel2.jpg" alt="">
    </div>
</body>
</html>